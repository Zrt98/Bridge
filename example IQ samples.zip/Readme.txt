Generated IQ samples are saved as MATLAB .mat files.

A-B.mat represents: target device number (1 to 10, specially 0 for BLE v5.1 tag) - position (1 to 9)

IQ samples are meanwhile generated from 4 different locators (IQData1 to IQData4) with the corresponding RSSI for each packet.
